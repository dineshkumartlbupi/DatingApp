export interface UserState {
  user: any | null;
  token: string | null;
}

export const FontFamily = {
  regular: "InterRegular",
  medium: "InterMedium",
  semiBold: "InterSemiBold",
  bold: "InterBold",
};

export const Borders = {
  radius1: 8,
  radius2: 16,
  radius3: 20,
  circle:90
};

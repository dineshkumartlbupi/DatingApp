import { Redirect } from "expo-router";
import React from "react";

export default function Home() {
  return <Redirect href="/(tabs)/home" />;
}

import { Redirect } from "expo-router";
import React from "react";

export default function Auth() {
  return <Redirect href="/auth/onboarding" />;
}
